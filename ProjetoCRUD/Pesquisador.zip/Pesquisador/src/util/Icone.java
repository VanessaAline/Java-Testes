package util;

public final class Icone {
	public String path = "C:\\Users\\r.de.lavor.rodrigues\\eclipse\\workspace\\Pesquisador\\doc\\";
	public String icon_main = path+"icon_main_small.png";

	public Icone() {

	}
	

}
